#ifndef versioned_lib_h__
#define versioned_lib_h__
 
extern int return_zero();
 
#endif  // versioned_lib_h__