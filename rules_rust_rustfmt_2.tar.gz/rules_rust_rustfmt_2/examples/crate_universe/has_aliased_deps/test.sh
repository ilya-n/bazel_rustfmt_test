#!/bin/bash -eux

true
